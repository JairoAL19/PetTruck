<!DOCTYPE html>

<html>

<?php echo $__env->make('partials.htmlheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
	 <section class="content">
	 	<?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    <?php echo $__env->yieldContent('main-content'); ?>
	 </section><!-- /.content -->	
</body>
</html>