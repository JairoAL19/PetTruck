<link rel="stylesheet" href="/css/nav.css">
<nav class="navbar navbar-default">
            <div class="container-fluid" style="height: 90px">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" id="navbar_brand" href="/" style="padding: 0px"><img class="logo_animated bounceInLeft" style="height: 75px; " src="/img/logo.png"></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right logo_animated bounceInRight" id="navbar_right" >
                        <li>
                            <a href="#" id="btn_login" style="margin: 0px; padding: 0px; margin-right: 15px; margin-top: 4%;color: black; letter-spacing: 1px; text-decoration: none">
                                <img src="/img/iniciosesion.png" style="width: 10px; margin-top: -3px">
                                <p style="font-size: 12px; font-family: Arial">Inciar Sesión</p>
                            </a>
                        </li>
                        <li>
                            <a href="#" style="margin: 0px; padding: 0px; margin-right: 15px; margin-top: 4%;color: black; letter-spacing: 1px; text-decoration: none">
                                <img src="/img/registro.png" style="margin-top: -3px">
                                <p style="font-size: 12px; font-family: Arial">Registrarse</p>
                            </a>
                        </li>
                    </ul>
                    <div style="height: 50px; width: auto; margin-left: 21%; margin-top: 35px; ">
                        <style>
                            a:hover{
                                color: black;
                                text-decoration: none;
                            }
                        </style>
                        <nav class="mynav">
                          <ul>
                            <li><a href="/"><p style="margin-bottom: 5%">HOME</p></a></li>
                            <li><a href="/Nosotros" ><p style="margin-bottom: 5%">NOSOTROS</p></a></li>
                            <li><a href="/Galería"><p style="margin-bottom: 5%">GALERÍA</p></a></li>
                            <li><a href="/Ayuda_s"><p style="margin-bottom: 5%">AYUDA SOCIAL</p></a></li>
                            <li><a href="/Contacto"><p style="margin-bottom: 5%">CONTACTO</p></a></li>
                            <li><a href="#"><p style="margin-bottom: 5%">MI CUENTA</p></a></li>
                          </ul>
                        </nav>
                        <span class="target"></span>

                        
                    </div>
                </div>
                
            </div>
        </nav>