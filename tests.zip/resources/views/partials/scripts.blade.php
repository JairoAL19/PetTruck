<script src="{{ asset('/js/jQuery-2.1.4.min.js') }}"></script>
<script src="{{ asset('/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ asset('/js/jquery-ui.js') }}" type="text/javascript"></script> 
<script src="{{ asset('/bxslider/jquery.bxslider.js') }}"></script>
<script src="{{ asset('/js/welcome.js') }}"></script>

<script src="/assets/js/paper-dashboard.js"></script>