<script src="<?php echo e(asset('/js/jQuery-2.1.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/jquery-ui.js')); ?>" type="text/javascript"></script> 
<script src="<?php echo e(asset('/bxslider/jquery.bxslider.js')); ?>"></script>
<script src="<?php echo e(asset('/js/welcome.js')); ?>"></script>

<script src="/assets/js/paper-dashboard.js"></script>