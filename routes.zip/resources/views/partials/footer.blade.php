        <div>
          <div id="footer_pg">              
              <div id="footer_pg_left"></div>              
              <div id="footer_pg_right">
                  <p>CONTÁCTANOS</p>
                  <div id="footer_pg_right_div"></div>
              </div>         
          </div>
        </div>
        <div id="footer_pg_texto">
            <div id="texto_left">
                <p id="texto_siguenos">SÍGUENOS EN:</p>
                <div id="subraya_left"></div>
                <div id="redes">
                    <a href="#"><div id="fb_img"></div></a>
                    <a href="#"><div id="instagram_img"></div></a>                   
                </div> 
                <div id="web">
                  <img src="/img/world.png">www.pet-truck.com
                </div>
                <div id="email_web">
                  <img src="/img/email.png">contacto@pet-truck.com
                </div>
                <div id="telefonos">
                  <img src="/img/phone.png">993-991-782 | 949-862-618
                </div>
                <div id="texto_nuestros">NUESTROS HORARIOS</div>
                <div id="box_horarios">
                      <div id="tex_dias">
                          LUNES - SÁBADO
                          <p>09 : 00 AM</p>
                          <p>08 : 00 PM</p>
                      </div>
                      <div id="tex_domin">
                          DOMINGOS
                          <p>09 : 00 AM</p>
                          <p>06 : 00 PM</p>
                      </div>
                </div>
            </div>
            <div id="texto_right">
                  <input id="inputcontacto" type="text" name="" value="¿Cuál es tu nombre completo?">
                  <input id="inputcontacto" type="text" name="" value="¿Cuál es tu correo?">
                  <input id="inputcontacto" type="text" name="" value="¿A qué teléfono te llamamos?">
                  <input id="inputcontacto" type="text" name="" value="¿Cuál es tu dirección exacta?">
                  <input id="inputcontacto" type="text" name="" value="Cuéntanos qué necesitas…">
                  <input id="submitcontacto" type="submit" name="">
            </div>            
        </div>
        <div id="bottom_footer">
            <a href="/"><img src="/img/logo.png"></a>
            <p id="bottom_footer_center">© Derechos reservados Pet Truck 2017</p>
            <p id="bottom_footer_right"><b>Web elaborada por:<a href="#"></b> El Rincón Creativo</p></a>
        </div>