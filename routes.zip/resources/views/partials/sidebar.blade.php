<div class="sidebar" id="sidebar_mobile" data-background-color="white" data-active-color="danger"> 
        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="/" class="simple-text" style="color: black">
                    <img style="height: 60px; " src="/img/logo.png">
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="/">
                        <i class="ti-direction-alt"></i>
                        <p>HOME</p>
                    </a>
                </li>
                <li>
                    <a href="/Nosotros">
                        <i class="ti-announcement"></i>
                        <p>NOSOTROS</p>
                    </a>
                </li>
                <li>
                    <a href="/Galería">
                        <i class="ti-camera"></i>
                        <p>GALERÍA</p>
                    </a>
                </li>
                <li>
                    <a href="/Ayuda_s">
                        <i class="ti-heart"></i>
                        <p>AYUDA SOCIAL</p>
                    </a>
                </li>
                <li>
                    <a href="/Contacto">
                        <i class="ti-headphone-alt"></i>
                        <p>CONTACTO</p>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="ti-user"></i>
                        <p>MI CUENTA</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>