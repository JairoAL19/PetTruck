                          //BXSLIDER   
                          $(document).ready(function(){
                                            $('.slider1').bxSlider({
                                              slideWidth: 317,
                                              minSlides: 2,
                                              maxSlides: 3,
                                              slideMargin: 0,
                                              auto: true,
                                              controls: false,
                                              randomStart: true,
                                              speed: 900,
                                              easing:'swing',
                                              autoDirection: 'prev',
                                            });
                                          });
                                          $(document).ready(function(){
                                            $('.slider2').bxSlider({
                                              slideWidth: 317,
                                              minSlides: 2,
                                              maxSlides: 3,
                                              slideMargin: 0,
                                              auto: true,
                                            });
                                          });